Minecraft-style widget buttons

Содержимое архива:
- buttons/button_blue.png — синяя кнопка, обычное состояние
- buttons/button_blue_hover.png — синяя кнопка, наведение (белая обводка)
- buttons/button_gray.png — серая кнопка, обычное состояние
- buttons/button_gray_hover.png — серая кнопка, наведение (белая обводка)
- buttons/button_red.png — красная кнопка, обычное состояние
- buttons/button_red_hover.png — красная кнопка, наведение (белая обводка)
- generate_minecraft_widget_buttons.py — код полной генерации текстур
- buttons_states_preview.png — лист предпросмотра, слева обычные состояния, справа hover.

Размер каждой кнопки: 597 × 52 px.
Вне контура используется прозрачность. Все текстуры сгенерированы кодом, без использования исходной фотографии.
