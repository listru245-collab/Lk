"""Generate separate clean Minecraft-style button textures.

The output is drawn entirely with Pillow primitives.  No source image is read.
Each colour has two assets: a normal state and a hover state with a white rim.
"""
from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path("/home/user/buttons")
OUT.mkdir(parents=True, exist_ok=True)

# Keeps compatibility with the original widgets canvas width.  Every exported
# button is a separate transparent PNG, 597 x 52 px.
W, H = 597, 52
BUTTON_X, BUTTON_W = 3, 591


def lerp(a, b, t):
    return tuple(round(a[i] * (1 - t) + b[i] * t) for i in range(3))


def make_button(palette, hovered=False):
    """Return a clean beveled texture. hovered=True adds an opaque white outline."""
    image = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(image)
    x, y, w, h = BUTTON_X, 0, BUTTON_W, H

    def rect(box, color):
        d.rectangle(box, fill=color)

    # Stepped, pixel-art outer silhouette.  All six button files use an outline.
    outer = (247, 250, 255, 255) if hovered else palette["outline"]
    rect((x + 3, y, x + w - 4, y + h - 1), outer)
    rect((x, y + 3, x + w - 1, y + h - 4), outer)

    # On hover the complete 2 px perimeter turns white, visibly separating the
    # selected item from the normal coloured/grey border.
    if hovered:
        white = (255, 255, 255, 255)
        rect((x + 3, y, x + w - 4, y + 1), white)
        rect((x, y + 3, x + 1, y + h - 4), white)
        rect((x + 3, y + h - 2, x + w - 4, y + h - 1), white)
        rect((x + w - 2, y + 3, x + w - 1, y + h - 4), white)

    # Black offset along the bottom/right makes the UI look like a raised game
    # widget instead of a flat rectangle.
    rect((x + 4, y + h - 4, x + w - 5, y + h - 1), palette["shadow"])
    rect((x + w - 4, y + 4, x + w - 1, y + h - 5), palette["shadow"])
    rect((x + 2, y + h - 3, x + w - 3, y + h - 1), palette["shadow"])

    # Reapply white at the outer lower/right edge after the drop-shadow.
    if hovered:
        rect((x + 3, y + h - 2, x + w - 4, y + h - 1), (255, 255, 255, 255))
        rect((x + w - 2, y + 3, x + w - 1, y + h - 4), (255, 255, 255, 255))

    # Colour-specific frame: cyan for blue, silver for grey, amber for red.
    rect((x + 4, y + 3, x + w - 5, y + 5), palette["rim_light"])
    rect((x + 3, y + 4, x + 5, y + h - 5), palette["rim_light"])
    rect((x + 6, y + 6, x + w - 7, y + 7), palette["rim_mid"])
    rect((x + 6, y + 6, x + 7, y + h - 7), palette["rim_mid"])

    # Dark inset, then an intentionally dot-free, smooth vertical face gradient.
    rect((x + 8, y + 8, x + w - 9, y + h - 9), palette["inset"])
    left, top, right, bottom = x + 10, y + 10, x + w - 11, y + h - 11
    for yy in range(top, bottom + 1):
        t = (yy - top) / (bottom - top)
        rect((left, yy, right, yy), lerp(palette["face_top"], palette["face_bottom"], t))

    # Clean raised face bevel.
    rect((left, top, right, top), palette["face_glint"])
    rect((left, bottom - 1, right, bottom), palette["face_shade"])
    rect((left - 1, top - 1, right + 1, top - 1), palette["inner_edge"])
    rect((left - 1, top - 1, left - 1, bottom + 1), palette["inner_edge"])
    rect((left - 1, bottom + 1, right + 1, bottom + 1), palette["inner_shadow"])
    rect((right + 1, top - 1, right + 1, bottom + 1), palette["inner_shadow"])
    return image


PALETTES = {
    "blue": {
        "outline": (5, 11, 30, 255), "shadow": (2, 5, 16, 255),
        "rim_light": (55, 229, 255, 255), "rim_mid": (13, 104, 219, 255),
        "inset": (4, 29, 96, 255), "face_top": (13, 174, 255),
        "face_bottom": (0, 77, 211), "face_glint": (87, 239, 255, 255),
        "face_shade": (0, 39, 157, 255), "inner_edge": (0, 49, 143, 255),
        "inner_shadow": (0, 19, 82, 255),
    },
    "gray": {
        "outline": (23, 25, 32, 255), "shadow": (9, 10, 14, 255),
        "rim_light": (241, 244, 242, 255), "rim_mid": (169, 176, 180, 255),
        "inset": (64, 69, 79, 255), "face_top": (186, 191, 193),
        "face_bottom": (126, 132, 138), "face_glint": (223, 228, 227, 255),
        "face_shade": (92, 98, 106, 255), "inner_edge": (129, 135, 142, 255),
        "inner_shadow": (59, 64, 72, 255),
    },
    "red": {
        "outline": (43, 9, 9, 255), "shadow": (21, 3, 5, 255),
        "rim_light": (255, 199, 29, 255), "rim_mid": (240, 85, 21, 255),
        "inset": (132, 21, 18, 255), "face_top": (255, 82, 45),
        "face_bottom": (204, 29, 26), "face_glint": (255, 157, 87, 255),
        "face_shade": (143, 14, 18, 255), "inner_edge": (175, 27, 20, 255),
        "inner_shadow": (91, 8, 13, 255),
    },
}

for name, palette in PALETTES.items():
    make_button(palette, hovered=False).save(OUT / f"button_{name}.png")
    make_button(palette, hovered=True).save(OUT / f"button_{name}_hover.png")

# A non-game preview, so every individual texture can be inspected together.
preview = Image.new("RGBA", (1206, 184), (11, 11, 16, 255))
for row, name in enumerate(("blue", "gray", "red")):
    y = row * 61
    preview.alpha_composite(Image.open(OUT / f"button_{name}.png"), (3, y))
    preview.alpha_composite(Image.open(OUT / f"button_{name}_hover.png"), (606, y))
preview.save("/home/user/buttons_states_preview.png")

print("Created separated normal and hover textures in /home/user/buttons/")
